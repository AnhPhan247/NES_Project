#include "contiki-conf.h"
#include "net/netstack.h"
#include "net/rime/rime.h"
#include "net/mac/tsch/tsch.h"
#include "net/mac/tsch/tsch-schedule.h"
#include "node-id.h"
#include "random.h"
#include "dev/uart0.h"
#include "leds.h"

#include "nodeidsetting.h"
// simulation or experiments
#define MYDEBUG 1
#if MYDEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

#define SEND_INTERVAL   ( CLOCK_SECOND/30)
#define EB_INTERVAL_START   (12*2)
#define EB_INTERVAL_END   (20*2)
#define UDP_PORT 1234

#define COORDINATOR_ID 1
#define COORDINATOR_ID2 2

static uint16_t br_seqno = 0;

static uint8_t app_started = 0;
static uint32_t start_asn = 0;

/*packet buffer for incoming data packets*/
static uint8_t app_packet_buff[10];

/* Buffers for received sensor data */
static uint16_t heart_rate_buff[8];
static uint16_t pressure_buff[8];

/* The current Absolute Slot Number (ASN) */
extern struct tsch_asn_t tsch_current_asn;
/*my asn */
static uint32_t accurate_asn;

static struct broadcast_conn broadcast;
static struct unicast_conn unicast;


/*---------------------------------------------------------------------------*/
PROCESS(broadcast_sender_process, "No-RPL Broadcast Application");
PROCESS(asn_process, "asn process");
//PROCESS(broadcast_reciever_process, "Broad-Rec process");

AUTOSTART_PROCESSES(&broadcast_sender_process, &asn_process);//,&broadcast_reciever_process
		/*---------------------------------------------------------------------------*/

static void broadcast_recv(struct broadcast_conn *c, const linkaddr_t *from) {
//	static uint8_t * msg;
//	PRINTF("Recv from: %u \n", from->u8[0]);
//	if (app_started == 0 && from->u8[0] == 2) {
//		msg = (uint8_t *) packetbuf_dataptr();
//
//		start_asn = (unsigned int) msg[0] | (unsigned int) msg[1] << 8
//				| (unsigned int) msg[2] << 16 | (unsigned int) msg[3] << 24;
//		app_started = 1;
//		PRINTF("RB \n");
//	}
}
static const struct broadcast_callbacks broadcast_call = { broadcast_recv };
static struct broadcast_conn broadcast;

/*---------------------------------------------------------------------------*/
void app_send_broadcast(uint32_t start_asn) {

	app_packet_buff[0] = start_asn & 0xFF;
	app_packet_buff[1] = (start_asn >> 8) & 0xFF;
	app_packet_buff[2] = (start_asn >> 16) & 0xFF;
	app_packet_buff[3] = (start_asn >> 24) & 0xFF;

	packetbuf_copyfrom(app_packet_buff, 4);
	packetbuf_set_attr(PACKETBUF_ATTR_MAC_SEQNO, br_seqno);
	packetbuf_set_addr(PACKETBUF_ADDR_RECEIVER, &tsch_broadcast_address);
	broadcast_send(&broadcast);
	br_seqno++;
	PRINTF("TB\n");
}

/*---------------------------------------------------------------------------*/
void app_send_unicast(uint16_t seqno, linkaddr_t link_address_dest) {

//	app_packet_buff[0] = seqno & 0xFF;
//	app_packet_buff[1] = (seqno >> 8) & 0xFF;
//	packetbuf_copyfrom(app_packet_buff, 2);
//	unicast_send(&unicast, &link_address_dest);

	// Boat base station sensor data!!
	static int16_t acc_x; //Range for Accelerometer 16g -235 to +270
	static int16_t acc_y; //Range for Accelerometer 16g -240 to +260
	static int16_t acc_z; //Range for Accelerometer 16g -240 to +270
	static int16_t speed;

	//printf("app_send_unicast\n");

	// Initial values
	int i;
	static uint8_t initiated = 0;
	if (initiated == 0) {
		acc_x = 230;
		acc_y = 230;
		acc_z = 230;

		speed = 15;

		for (i=0; i<8; i++) {
			heart_rate_buff[i] = 0;
			pressure_buff[i] = 0;
		}

		initiated = 1;
	}


	// Send pressure data every 0.25 seconds
	if (seqno % 2  == 0) {
		// Change values randomly
		switch (random_rand() % 8) {
		case 0:
			if (acc_x >= -235 && acc_x <= 270)
				acc_x++;
			break;
		case 1:
			if (acc_y >= -240 && acc_y <= 260)
				acc_y++;
			break;
		case 2:
			if (acc_z >= -240 && acc_z <= 270)
				acc_z++;
			break;
		case 3:
			if (speed >= 1 && speed <= 30)
				speed++;
			break;

		case 4:
			if (acc_x >= -235 && acc_x <= 270)
				acc_x--;
			break;
		case 5:
			if (acc_y >= -240 && acc_y <= 260)
				acc_y--;
			break;
		case 6:
			if (acc_z >= -240 && acc_z <= 270)
				acc_z--;
			break;
		case 7:
			if (speed >= 1 && speed <= 30)
				speed--;
			break;
		}

		// Send accelerometer and pressure data

		uint16_t message[14];
		message[0] = seqno;
		message[1] = 1; // Message type is 1!
		message[2] = acc_x;
		message[3] = acc_y;
		message[4] = acc_x;
		message[5] = speed;
		for (i = 0; i < 8; i++) {
			message[6 + i] = pressure_buff[i];
			// Reset value whenever it is send
			// (Note: this might have a small race condition issue)
			pressure_buff[i] = 0;
		}

		// Send it
		packetbuf_copyfrom(message, sizeof(message));
		unicast_send(&unicast, &link_address_dest);

		printf("Sent pressure data %u\n", seqno);

	}

	// Send heart rate data every second
	if (seqno % 8 == 1) {
		uint16_t heart_rate_msg[10];
		heart_rate_msg[0] = seqno;
		heart_rate_msg[1] = 2; // Type==2
		for (i = 0; i < 8; i++) {
			heart_rate_msg[2+i]= heart_rate_buff[i];
			// Reset value whenever it is send
			// (Note: this might have a small race condition issue)
			heart_rate_buff[i] = 0;
		}

		// Send it
		packetbuf_copyfrom(heart_rate_msg, sizeof(heart_rate_msg));
		unicast_send(&unicast, &link_address_dest);
		printf("Sent heart rate data %u\n", seqno);
	}
}

/*---------------------------------------------------------------------------*/
/* This function is called for every incoming unicast packet. */
static void recv_uc(struct unicast_conn *c, const linkaddr_t *from) {
	static uint8_t *msg;

	uint16_t seqno;

	/* Grab the pointer to the incoming data. */
	msg = packetbuf_dataptr();
	seqno = msg[1] << 8 | msg[0];

	uint16_t data = msg[3] << 8 | msg[2];
	uint8_t from_id = from->u8[0];

	//printf("RU: %u %u\n", from->u8[0], seqno);

	// ID 3-10: heart rate, ID 11-18: pressure
	if (from_id >= 3 && from_id <= 10) {
		printf("Received heart rate %u from node %u (%u)\n", data, from_id, seqno);
		heart_rate_buff[from_id - 3] = data;
	} else if (from_id >= 11 && from_id <= 18) {
		printf("Received pressure %u from node %u (%u)\n", data, from_id, seqno);
		pressure_buff[from_id - 11] = data;
	} else {
		printf("Received unknown data from node %u (%u)\n", from_id, seqno);
	}

#if MYDEBUG == 0
	uart0_writeb( from->u8[0]);
	uart0_writeb(msg[0]);
	uart0_writeb(msg[1]);
	uart0_writeb((uint8_t)((tsch_current_asn.ls4b-msg_ASN)));
	uart0_writeb((uint8_t)(((tsch_current_asn.ls4b-msg_ASN)) >>8));
	uart0_writeb(msg[6]);
	uart0_writeb(msg[7]);
	uart0_writeb(msg[8]);
	uart0_writeb(msg[9]);

#endif

}

/*---------------------------------------------------------------------------*/
static void sent_uc(struct unicast_conn *ptr, int status, int num_tx) {
	//PRINTF("SU %u %u\n", num_tx,status);
}

static const struct unicast_callbacks unicast_callbacks = { recv_uc, sent_uc };
static struct unicast_conn unicast;

/*---------------------------------------------------------------------------*/
/* This function initialize the schedule. */
void init_schedule() {
	struct tsch_slotframe *sf;
	uint8_t link_options;
	uint8_t timeslot;
	linkaddr_t link_address;

	tsch_schedule_remove_all_slotframes();

	sf = tsch_schedule_add_slotframe(0, NUMBER_NODE + NUMBER_SHARED_LINKS + EXTRA_SLOTS);
	if (node_id == COORDINATOR_ID) {
		link_options = LINK_OPTION_TX;
	} else {
		link_options = LINK_OPTION_RX | LINK_OPTION_TIME_KEEPING;
	}

	tsch_schedule_add_link(sf, link_options, LINK_TYPE_ADVERTISING, &tsch_broadcast_address, 0, 0);

	memset(&link_address, 0, LINKADDR_SIZE);
	link_address.u8[0] = COORDINATOR_ID & 0xff;

	for (timeslot = 1; timeslot <= NUMBER_NODE - 1; timeslot++) {
		if (node_id == (timeslot + 1)) {
			tsch_schedule_add_link(sf, LINK_OPTION_TX, LINK_TYPE_NORMAL, &link_address, timeslot, 0);
		} else if (node_id == COORDINATOR_ID) {
			tsch_schedule_add_link(sf, (LINK_OPTION_RX), LINK_TYPE_NORMAL, &tsch_broadcast_address, timeslot, 0);
		}
	}
	for (timeslot = NUMBER_NODE; timeslot <= NUMBER_NODE - 1 + NUMBER_SHARED_LINKS; timeslot++) {
		if (node_id == COORDINATOR_ID) {
			tsch_schedule_add_link(sf,LINK_OPTION_RX, LINK_TYPE_NORMAL, &tsch_broadcast_address, timeslot, 0);
		} else {
			tsch_schedule_add_link(sf, (LINK_OPTION_TX | LINK_OPTION_SHARED), LINK_TYPE_NORMAL, &link_address, timeslot, 0);
		}
	}
}

/*---------------------------------------------------------------------------*/
PROCESS_THREAD(broadcast_sender_process, ev, data) {
	PROCESS_BEGIN();

	static uint32_t start_asn;
	static struct etimer event_timer, end_timer;

	static uint16_t seqno;

	leds_init();
	PRINTF("App started\n");

	//if(!nodeidsetting_init())
	//PRINTF("node id settings failed\n");
	node_id_restore();

	PRINTF("link addrs %u\n", linkaddr_node_addr.u8[0]);
	PRINTF("node id %u\n", node_id);

	/* Set node with ID == 1 as coordinator, handy in Cooja. */
	if (node_id == COORDINATOR_ID) {
		tsch_set_coordinator(1);
	}

	NETSTACK_MAC.init();

	etimer_set(&event_timer, CLOCK_SECOND * 10);
	PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
	etimer_stop(&event_timer);

	PRINTF("App: %u starting\n", node_id);
	PRINTF("App: %u.%u starting\n", linkaddr_node_addr.u8[0], linkaddr_node_addr.u8[1]);

	NETSTACK_MAC.off(0);
	init_schedule();
	NETSTACK_MAC.on();

	tsch_set_eb_period(1 * CLOCK_SECOND);
	leds_toggle(LEDS_RED);

	etimer_set(&event_timer, CLOCK_SECOND * 10);
	PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
	etimer_stop(&event_timer);

	broadcast_open(&broadcast, 129, &broadcast_call);
	unicast_open(&unicast, 146, &unicast_callbacks);

	start_asn = accurate_asn + 100;

	int i = 0;
	while (i < 20) {
		leds_toggle(LEDS_RED);
		app_send_broadcast(start_asn);
		i++;
	}

	/* Send to coach device */
	static linkaddr_t link_address_coach;
	memset(&link_address_coach, 0, LINKADDR_SIZE);
	link_address_coach.u8[0] = COORDINATOR_ID2 & 0xff;

//	printf("NUMBER_NODE: %u, NUMBER_SHARED_LINKS: %u, EXTRA_SLOTS: %u\n",
//			NUMBER_NODE, NUMBER_SHARED_LINKS, EXTRA_SLOTS);

	seqno = 0;
	while (1) {
		etimer_set(&event_timer, 0.125 * CLOCK_SECOND); // packet generation rate
		PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
		app_send_unicast(seqno, link_address_coach);
		seqno++;
		leds_toggle(LEDS_RED);
	}
//	while (1) {
//		/*while(app_started != 1){
//		 PRINTF("App started = %u \n", app_started);
//		 etimer_set(&event_timer, CLOCK_SECOND/4);
//		 PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
//		 }
//		 */
////		while (start_asn > accurate_asn) {
////			etimer_set(&event_timer, CLOCK_SECOND / 100);
////			PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
////		}
////		PRINTF("Process working\n");
//		seqno = 0;
////		etimer_set(&end_timer, (EXPERIMENT_DURATION) * CLOCK_SECOND + 10);
//		while (1) {
////			if (tsch_is_associated) {
////
////				etimer_set(&event_timer, 0.25 * CLOCK_SECOND); // packet generation rate
////				PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
//
//				app_send_unicast(seqno, link_address_coach);
//				//PRINTF("SRec %u\n",seqno);
//				seqno++;
//				leds_toggle(LEDS_RED);
//			}
////			etimer_set(&event_timer,
////					CLOCK_SECOND * (NUMBER_NODE + NUMBER_SHARED_LINKS - 2)
////							/ 64);
////			PROCESS_WAIT_UNTIL(
////					(etimer_expired(&event_timer) || etimer_expired(&end_timer)));
////			if (etimer_expired(&end_timer))
////				break;
//		}
//	}
	PROCESS_END();
}
/*---------------------------------------------------------------------------*/

PROCESS_THREAD(asn_process, ev, data) {
	PROCESS_BEGIN();
	static struct etimer et1;
	static uint32_t prev_asn;

	while (1) {
		if (prev_asn != tsch_current_asn.ls4b) {
			accurate_asn = prev_asn;
			prev_asn = tsch_current_asn.ls4b;
		}
		accurate_asn = accurate_asn + 1;
		if (accurate_asn > tsch_current_asn.ls4b)
			accurate_asn = tsch_current_asn.ls4b;
		etimer_set(&et1, CLOCK_SECOND / 64);
		PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et1));
	}

	PROCESS_END();
}
