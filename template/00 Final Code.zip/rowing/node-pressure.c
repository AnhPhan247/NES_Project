#include "contiki-conf.h"
#include "net/netstack.h"
#include "net/rime/rime.h"
#include "net/mac/tsch/tsch.h"
#include "net/mac/tsch/tsch-schedule.h"
#include "node-id.h"
#include "random.h"
#include "leds.h"

#include "nodeidsetting.h"

#define MYDEBUG 1
#if MYDEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

#define SEND_INTERVAL   (CLOCK_SECOND/30)
#define EB_INTERVAL_START   (12*2)
#define EB_INTERVAL_END   (20*2)
#define UDP_PORT 1234

#define COORDINATOR_ID 0x01

/*packet buffer for incoming data packets*/
static uint8_t app_packet_buff[10];

/* The current Absolute Slot Number (ASN) */
extern struct tsch_asn_t tsch_current_asn;
/*my asn */
static uint32_t accurate_asn;

static uint8_t app_started = 0;
static uint32_t start_asn= 0;


static struct broadcast_conn broadcast;
static struct unicast_conn unicast;


/*---------------------------------------------------------------------------*/
PROCESS(broadcast_sender_process, "No-RPL Broadcast Application");
PROCESS(asn_process, "asn process");

AUTOSTART_PROCESSES(&broadcast_sender_process,&asn_process);

/*---------------------------------------------------------------------------*/

static void
broadcast_recv(struct broadcast_conn *c, const linkaddr_t *from)
{
	static uint8_t * msg;
	if( app_started == 0 && from->u8[0] == 1){
		msg = (uint8_t *)packetbuf_dataptr();

		start_asn = (unsigned int)msg[0] |
				(unsigned int)msg[1] << 8 |
				(unsigned int)msg[2] << 16 |
				(unsigned int)msg[3] << 24;
		app_started = 1;
		PRINTF("RB \n");
	}
}
static const struct broadcast_callbacks broadcast_call = {broadcast_recv};

/*---------------------------------------------------------------------------*/
void
app_send_broadcast()
{
}

/*---------------------------------------------------------------------------*/
void
app_send_unicast(uint16_t seqno, linkaddr_t link_address_dest)
{

	app_packet_buff[0] = seqno & 0xFF;
	app_packet_buff[1] = (seqno >> 8) & 0xFF;

	// Simulate pressure value
	static uint16_t pressure = 800;

	switch (random_rand() % 3) {
	case 0:
		if (pressure>=700 && pressure <= 900) {
			pressure++;
		}
		break;

	case 1:
		if (pressure>=700 && pressure <= 900) {
			pressure--;
		}
		break;
	}

	// Send the data
	app_packet_buff[2] = pressure & 0xFF;
	app_packet_buff[3] = (pressure >> 8)& 0xFF;
	packetbuf_copyfrom(app_packet_buff, 4);
	unicast_send(&unicast, &link_address_dest);

	printf("Sent pressure data %u: %u\n", seqno, pressure);
}
/*---------------------------------------------------------------------------*/
/* This function is called for every incoming unicast packet. */
static void
recv_uc(struct unicast_conn *c, const linkaddr_t *from)
{
}

/*---------------------------------------------------------------------------*/
static void
sent_uc(struct unicast_conn *ptr, int status, int num_tx)
{
	//PRINTF("SU %u %u\n", num_tx,status);
}

static const struct unicast_callbacks unicast_callbacks = {recv_uc , sent_uc };

/*---------------------------------------------------------------------------*/
/* This function initialize the schedule. */
void init_schedule() {
	struct tsch_slotframe *sf;
	uint8_t link_options;
	uint8_t timeslot;
	linkaddr_t link_address;

	tsch_schedule_remove_all_slotframes();

	sf = tsch_schedule_add_slotframe(0, NUMBER_NODE + NUMBER_SHARED_LINKS + EXTRA_SLOTS);
	if (node_id == COORDINATOR_ID) {
		link_options = LINK_OPTION_TX;
	} else {
		link_options = LINK_OPTION_RX | LINK_OPTION_TIME_KEEPING;
	}

	tsch_schedule_add_link(sf, link_options, LINK_TYPE_ADVERTISING, &tsch_broadcast_address, 0, 0);

	memset(&link_address, 0, LINKADDR_SIZE);
	link_address.u8[0] = COORDINATOR_ID & 0xff;

	for (timeslot = 1; timeslot <= NUMBER_NODE - 1; timeslot++) {
		if (node_id == (timeslot + 1)) {
			tsch_schedule_add_link(sf, LINK_OPTION_TX, LINK_TYPE_NORMAL, &link_address, timeslot, 0);
		} else if (node_id == COORDINATOR_ID) {
			tsch_schedule_add_link(sf, (LINK_OPTION_RX), LINK_TYPE_NORMAL, &tsch_broadcast_address, timeslot, 0);
		}
	}
	for (timeslot = NUMBER_NODE; timeslot <= NUMBER_NODE - 1 + NUMBER_SHARED_LINKS; timeslot++) {
		if (node_id == COORDINATOR_ID) {
			tsch_schedule_add_link(sf,LINK_OPTION_RX, LINK_TYPE_NORMAL, &tsch_broadcast_address, timeslot,
					0);
		} else {
			tsch_schedule_add_link(sf, (LINK_OPTION_TX | LINK_OPTION_SHARED), LINK_TYPE_NORMAL, &link_address, timeslot, 0);
		}
	}
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(broadcast_sender_process, ev, data)
{
	static struct etimer event_timer,  end_timer;

	static linkaddr_t link_address_cord;
	static uint16_t seqno;


	PROCESS_BEGIN();

	PRINTF("App started\n");

	leds_init();

	//if(!nodeidsetting_init())
	//PRINTF("node id settings failed\n");
	node_id_restore();

	PRINTF("link addrs %u\n",linkaddr_node_addr.u8[0]);
	PRINTF("node id %u\n",node_id);

	NETSTACK_MAC.init();

	etimer_set(&event_timer, CLOCK_SECOND*1);
	PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
	etimer_stop(&event_timer);

	PRINTF("App: %u starting\n", node_id);
	PRINTF("App: %u.%u starting\n", linkaddr_node_addr.u8[0], linkaddr_node_addr.u8[1]);

	NETSTACK_MAC.off(0);
	init_schedule();
	NETSTACK_MAC.on();
	leds_toggle(LEDS_RED);

	etimer_set(&event_timer, CLOCK_SECOND*5);
	PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
	etimer_stop(&event_timer);

	broadcast_open(&broadcast, 129, &broadcast_call);
	unicast_open(&unicast, 146, &unicast_callbacks);

	memset(&link_address_cord, 0, LINKADDR_SIZE);
	link_address_cord.u8[0] = COORDINATOR_ID & 0xff;


	while(1){
		while(app_started != 1){
			etimer_set(&event_timer, CLOCK_SECOND/4);
			PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
		}

		while(start_asn>accurate_asn){
			etimer_set(&event_timer, CLOCK_SECOND/100);
			PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));
		}

		seqno = 0;

		etimer_set(&end_timer,  (EXPERIMENT_DURATION) *CLOCK_SECOND );
		while(1) {
			if(tsch_is_associated){

				etimer_set(&event_timer, 0.25*CLOCK_SECOND);            // packet generation rate
				PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&event_timer));

				app_send_unicast( seqno,  link_address_cord);
				//PRINTF("TU %u\n",seqno);
				seqno ++;
				leds_toggle(LEDS_RED);
			}
//			etimer_set(&event_timer, CLOCK_SECOND*(NUMBER_NODE+NUMBER_SHARED_LINKS-2)/64);
//			PROCESS_WAIT_UNTIL((etimer_expired(&event_timer)||etimer_expired(&end_timer)));
//			if(etimer_expired(&end_timer)) {
//				break;
//			}
		}
	}
	PROCESS_END();
}
/*---------------------------------------------------------------------------*/

PROCESS_THREAD(asn_process, ev, data)
{
	PROCESS_BEGIN();
	static struct etimer et1;
	static uint32_t prev_asn;

	while(1)
	{
		if(prev_asn != tsch_current_asn.ls4b){
			accurate_asn = prev_asn;
			prev_asn = tsch_current_asn.ls4b;
		}
		accurate_asn = accurate_asn +1;
		if(accurate_asn> tsch_current_asn.ls4b)
			accurate_asn = tsch_current_asn.ls4b;
		etimer_set(&et1, CLOCK_SECOND / 64);
		PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et1));
	}

	PROCESS_END();
}
