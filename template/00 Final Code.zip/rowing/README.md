# Rowing boat sensor network


## How to simulate in Cooja

1. Create 4 different Sky mote types:
  * Boat base station using `sink.c`
  * Coach device using `sink-coach.c`
  * Heart rate sensor using `node-heart-rate.c`
  * Pressure sensor using `node-pressure.c`
2. Add nodes to the simulation:
  * 1x boat base station with ID 1
  * 1x coach device with ID 2
  * 8x heart rate sensor with ID 3 to 10
  * 8x pressure sensor with ID 11 to 18
3. Start the simulation. It can take up to 1 minute simulated time for the
  network to be created. Make sure that the nodes are in each other's range
  during the startup phase.


## Code overview

* `node-heart-rate.c`: This module sends a heart rate every second to node with
  ID 1. Packet payload format: first 2 bytes sequence number, following 2
  bytes heart rate, little endian.
* `node-pressure.c`: Sends pressure data every 0.05 seconds to node with ID 1.
  Payload format: 2 bytes sequence number, 2 bytes current pressure value.
* `sink.c`: Boat base station, receives heart rate and pressure data. Looks at
  the sender node ID to determine whether it is a heart rate or pressure
  device.
  Sends sensor data to the device with ID 2 (coach) every 0.05 seconds. It
  sends 2 types of messages, either a message with pressure and accelerometer
  data every 0.05 seconds, and a message with heart rate data every second.
  * Type 1: 2 bytes sequence no, 2 bytes message type (1), 3x2 bytes
    accelerometer x/y/z, 2 bytes speed, 8x2 bytes pressure data.
  * Type 2: 2 bytes sequence no, 2 bytes message type (2), 8x2 bytes heart rate
    data.
* `sink-coach.c`: Coach device, receives the sensor data from the boat base
  station.


