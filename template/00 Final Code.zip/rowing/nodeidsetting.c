/*
 * Copyright (c) 2014, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */
/**
 * \file
 *         Code managing id<->mac address<->IPv6 address mapping, and doing this
 *         for different deployment scenarios: Cooja, Nodes, Indriya or Twist testbeds
 *
 * \author Simon Duquennoy <simonduq@sics.se>
 */

#include "contiki-conf.h"
#include "sys/node-id.h"
#include "net/rpl/rpl.h"
#include "net/mac/tsch/tsch.h"
#include "net/ip/uip-debug.h"
#include "net/linkaddr.h"
#include "random.h"
#include <string.h>
#include "nodeidsetting.h"

#ifndef WITH_TSCH
#define WITH_TSCH 1
#endif

#define WITH_IPV6_SETT 0

 extern unsigned char node_mac[8];

/* ID<->MAC address mapping */
struct id_mac {
  uint16_t id;
  macaddr_t mac;
};

/* List of ID<->MAC mapping used for different deployments */
static const struct id_mac id_mac_list[] = {
	{  1, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x1A}}},
	{  2, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xFA}}},
	{  3, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x46}}},
	{  4, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x21}}},
	{  5, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xEB}}},
	{  6, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x4F}}},
	{  7, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xDB}}},
	{  8, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x30}}},
	{  9, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xEF}}},
	{ 10, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x36}}},
	{ 11, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x4B}}},
	{ 12, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xDD}}},
	{ 13, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x17}}},
	{ 14, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xDE,0x34}}},
	{ 15, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x26}}},
	{ 16, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x19}}},
	{ 17, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x06}}},
	{ 18, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x4E}}},
	{ 19, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x0E}}},
	{ 20, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x38}}},
	{ 21, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xD1}}},
	{ 22, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xD3}}},
	{ 23, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x3B}}},
	{ 24, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xE0,0x0A}}},
	{ 25, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x01}}},
	{ 26, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xC8}}},
	{ 27, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x10}}},
	{ 28, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x4D}}},
	{ 29, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xFA,0x3E}}},
	{ 30, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xBF}}},
	{ 31, {{0x00,0x15,0x8D,0x00,0x00,0x57,0xF9,0xD4}}},
	{ 0, { { 0,0,0,0,0,0,0,0 } } }
};

/* Returns the node's node-id */
uint16_t
get_node_id()
{
  return node_id_from_mac((const macaddr_t *)node_mac);

}
/* Returns a node-id from a node's linkaddr */
uint16_t
node_id_from_mac(const macaddr_t *addr)
{
#if IN_COOJA
  if(addr == NULL) {
    return 0;
  } else {
    return addr->u8[7];
  }
#else /* IN_COOJA */
  if(addr == NULL) {
    return 0;
  }
  const struct id_mac *curr = id_mac_list;
  while(curr->id != 0) {
    /* Assume network-wide unique 16-bit MAC addresses */
    if(curr->mac.u8[6] == addr->u8[6] && curr->mac.u8[7] == addr->u8[7]) {
      return curr->id;
    }
    curr++;
  }
  return 0;
#endif /* IN_COOJA */
}

#if WITH_IPV6_SETT
/* Returns a node-id from a node's IPv6 address */
void
linkaddr_from_ipaddr( linkaddr_t *linkaddr, const uip_ipaddr_t *addr)
{
  memcpy(linkaddr, addr->u8 + 8, LINKADDR_SIZE);

}
#endif

int
nodeidsetting_init(void)
{
	static macaddr_t lladdr;
#if WITH_IPV6_SETT
	uip_ipaddr_t global_ipaddr;
#endif

	static uint16_t nodeid = 0;

	nodeid = get_node_id();

	if(nodeid == 0) {
	NETSTACK_RDC.off(0);
	NETSTACK_MAC.off(0);
	return 0;
	}

	node_id_burn(nodeid);

	lladdr.u8[0] = nodeid & 0xFF;
	lladdr.u8[1] = 0x00;
	lladdr.u8[2] = 0x00;
	lladdr.u8[3] = 0x00;
	lladdr.u8[4] = 0x00;
	lladdr.u8[5] = 0x00;
	lladdr.u8[6] = 0x00;
	lladdr.u8[7] = 0x00;

	linkaddr_set_node_addr((linkaddr_t *) &lladdr);

#if WITH_IPV6_SETT
	global_ipaddr.u8[0] = 0x00;
	global_ipaddr.u8[1] = 0x00;
	global_ipaddr.u8[2] = 0x00;
	global_ipaddr.u8[3] = 0x00;
	global_ipaddr.u8[4] = 0x00;
	global_ipaddr.u8[5] = 0x00;
	global_ipaddr.u8[6] = 0x00;
	global_ipaddr.u8[7] = 0x00;
	memcpy(global_ipaddr.u8 + 8, &lladdr, 8);

	uip_ds6_addr_add(&global_ipaddr, 0, ADDR_AUTOCONF);
#endif

	NETSTACK_MAC.on();

	return 1;
}


